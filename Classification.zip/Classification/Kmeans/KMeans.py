# roc curve and auc
import numpy as np, pandas as pd, seaborn as sn
from sklearn.cluster import KMeans  
import seaborn as sns; sns.set()  # for plot styling
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
from sklearn.metrics import average_precision_score
from sklearn.metrics import precision_recall_curve
from inspect import signature
from sklearn.model_selection import train_test_split

dataset = pd.read_csv("heart_failure_clinical_records_dataset.csv")

dataset.head()

X = dataset.iloc[:,0:12].values
y = dataset.iloc[:, 12].values


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)


kmeans = KMeans(n_clusters = 2, init = 'k-means++', max_iter = 2, n_init = 9, random_state = 0)
y_kmeans = kmeans.fit_predict(X)

centroids = kmeans.cluster_centers_

average_precision = average_precision_score(y, y_kmeans)
precision, recall, _ = precision_recall_curve(y, y_kmeans)


# In matplotlib < 1.5, plt.fill_between does not have a 'step' argument
step_kwargs = ({'step': 'post'}
               if 'step' in signature(plt.fill_between).parameters
               else {})
plt.step(recall, precision, color='b', alpha=0.2,
         where='post')
plt.fill_between(recall, precision, alpha=0.2, color='b', **step_kwargs)

plt.xlabel('Recall')
plt.ylabel('Precision')
plt.ylim([0.0, 1.05])
plt.xlim([0.0, 1.0])
plt.title('2-class Precision-Recall curve: AP={0:0.2f}'.format(average_precision))
plt.show()

accuracy = accuracy_score(y_kmeans, y)
print ('\nClasification report:\n',classification_report(y, y_kmeans))




confusion_matrix = confusion_matrix(y, y_kmeans)
df_cm = pd.DataFrame(confusion_matrix, index = [i for i in "01"], columns = [i for i in "01"])
plt.figure(figsize = (10,7))

sn.heatmap(df_cm, annot=True)
plt.show()

