import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt, seaborn as sn
from matplotlib import pyplot
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.model_selection import  cross_val_score
from sklearn.metrics import average_precision_score
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import precision_recall_curve
from inspect import signature
from sklearn.datasets import make_classification
from imblearn.over_sampling import SMOTE


dataset = pd.read_csv("heart_failure_clinical_records_dataset.csv")

#ejection fraction
X = dataset.iloc[:, 4].values.reshape(-1, 1)  # values converts it into a numpy array
Y = dataset.iloc[:, 12].values.reshape(-1, 1)  # -1 means that calculate the dimension of rows, but have 1 column

sm = SMOTE(random_state = 0)
X, Y = sm.fit_sample(X, Y.ravel())

x_train, x_test, y_train, y_test = train_test_split(X, Y, random_state=0)


# Create a Logistic Regression Object, perform Logistic Regression
log_reg = LogisticRegression()
log_reg.fit(x_train, y_train)



# Perform prediction using the test dataset
y_pred = log_reg.predict(x_test)


#train model with cv of 5 
cv_scores = cross_val_score(log_reg, X, Y, cv=5)

print('\ncv_scores mean:{}'.format(np.mean(cv_scores)))
print('\ncv_score variance:{}'.format(np.var(cv_scores)))
print('\ncv_score dev standard:{}'.format(np.std(cv_scores)))
print('\n')



probs = log_reg.predict_proba(x_test)
# keep probabilities for the positive outcome only
probs = probs[:, 1]

auc = roc_auc_score(y_test, probs)
print('AUC: %.3f' % auc)




# calculate roc curve
fpr, tpr, thresholds = roc_curve(y_test, probs)
# plot no skill
pyplot.plot([0, 1], [0, 1], linestyle='--')
# plot the roc curve for the model
pyplot.plot(fpr, tpr, marker='.')
pyplot.xlabel('FP RATE')
pyplot.ylabel('TP RATE')
pyplot.title('AUC ROC : AP={0:0.3f}'.format(auc))
# show the plot
pyplot.show()





average_precision = average_precision_score(y_test, y_pred)
precision, recall, _ = precision_recall_curve(y_test, y_pred)



step_kwargs = ({'step': 'post'}
               if 'step' in signature(plt.fill_between).parameters
               else {})
plt.step(recall, precision, color='b', alpha=0.2,
         where='post')
plt.fill_between(recall, precision, alpha=0.2, color='b', **step_kwargs)

plt.xlabel('Recall')
plt.ylabel('Precision')
plt.ylim([0.0, 1.05])
plt.xlim([0.0, 1.0])
plt.title('2-class Precision-Recall curve: AP={0:0.2f}'.format(average_precision))
print ('\nClassification report:\n',classification_report(y_test, y_pred))
print ('\nConfusion matrix:\n',confusion_matrix(y_test, y_pred))

confusion_matrix = confusion_matrix(y_test, y_pred) 
df_cm = pd.DataFrame(confusion_matrix, index = [i for i in "01"], columns = [i for i in "01"])
plt.figure(figsize = (10,7))
sn.heatmap(df_cm, annot=True)
plt.show()

f1 = f1_score(y_test, y_pred)



data = {'variance': np.var(cv_scores), 'standard dev': np.std(cv_scores)}
names = list(data.keys())
values = list(data.values())
fig,axs = plt.subplots(1, 1, figsize=(6, 3), sharey = True)
axs.bar(names, values)
plt.show()

